String APIKEY = "AIzaSyCOw9YpGz1D66DlGw5iD8q3SFLrK9WOwKU";
String BaseURL =
    "https://generativelanguage.googleapis.com/v1beta2/models/text-bison-001:generateText?key=YOUR_API_KEY";
