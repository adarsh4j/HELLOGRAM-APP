import 'package:flutter/material.dart' show Color;

class ColorsFrave {

  static const Color primary = Color(0xff0C6CF2);
  static const Color secundary = Color(0xff002C8B);
  static const Color background = Color(0xff21242C);

}
