class Environment {
  static const String baseUrl = 'http://192.168.77.84:7070/';

  static const String urlApi = 'http://192.168.77.84:7070/api';
}
